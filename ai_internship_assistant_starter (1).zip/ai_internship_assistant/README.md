# AI Internship Assistant — Starter Project

## Features
- Module 1: Create a task and generate a task explanation once per task; ask follow-up questions.
- Module 2: Enter a confirmed review date/time/link and send an email to the intern.
- Module 3: Upload PDF, DOCX, or TXT reports and receive AI-generated feedback.
- Progress: Track task status, record supervisor approval, and mark the internship complete when all tasks are approved.

## Requirements
- Python 3.10 or newer
- An OpenAI API key with API access and billing configured if required
- SMTP email credentials if you want to send real emails

## Run on Windows / VS Code
1. Install Python from https://www.python.org/downloads/
2. Open this folder in VS Code.
3. Open Terminal > New Terminal.
4. Create a virtual environment:
   `python -m venv .venv`
5. Activate it in PowerShell:
   `.\.venv\Scripts\Activate.ps1`
   If PowerShell blocks activation, use Command Prompt and run:
   `.venv\Scripts\activate.bat`
6. Install packages:
   `python -m pip install -r requirements.txt`
7. Copy `.env.example` to `.env`.
8. Put your API key in `.env`. Do not share the key or upload `.env` to GitHub.
9. Configure SMTP values only if you want to send review emails. For Gmail, use an App Password when eligible; do not use your normal account password.
10. Run:
    `streamlit run app.py`
11. Your browser should open the local app, usually at `http://localhost:8501`.

## Important
- The task, review date/time, and meeting link must be supplied/confirmed by an authorized supervisor.
- AI feedback is advisory; it does not execute submitted code and does not replace supervisor approval.
- This is a prototype, not a production-ready company system. It does not yet have user authentication or role-based access control.
- Uploaded reports are processed by the app and report text is sent to the configured AI API for evaluation. Do not upload confidential company material unless your company permits it.
- The local SQLite database is stored in `internship_assistant.db`.
