import os
import re
import smtplib
import sqlite3
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv
from openai import OpenAI
from pypdf import PdfReader
from docx import Document

load_dotenv()
APP_DIR = Path(__file__).parent
DB_PATH = APP_DIR / "internship_assistant.db"
MODEL = os.getenv("OPENAI_MODEL", "gpt-5.5")

st.set_page_config(page_title="AI Internship Assistant", page_icon="🤖", layout="wide")


# -------------------- Database --------------------
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS interns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            started_at TEXT NOT NULL,
            internship_complete INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            intern_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            instructions TEXT NOT NULL,
            expected_output TEXT NOT NULL DEFAULT '',
            due_date TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Assigned',
            explained INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            FOREIGN KEY(intern_id) REFERENCES interns(id)
        );
        CREATE TABLE IF NOT EXISTS submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER NOT NULL,
            filename TEXT NOT NULL,
            feedback TEXT NOT NULL,
            status TEXT NOT NULL,
            submitted_at TEXT NOT NULL,
            FOREIGN KEY(task_id) REFERENCES tasks(id)
        );
        CREATE TABLE IF NOT EXISTS review_emails (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER NOT NULL,
            review_date TEXT NOT NULL,
            review_time TEXT NOT NULL,
            meeting_link TEXT NOT NULL,
            recipient TEXT NOT NULL,
            sent_at TEXT NOT NULL,
            FOREIGN KEY(task_id) REFERENCES tasks(id)
        );
        """)
        conn.commit()


def get_or_create_intern(name, email):
    email = email.strip().lower()
    with db() as conn:
        row = conn.execute("SELECT * FROM interns WHERE email=?", (email,)).fetchone()
        if row:
            # Keep the existing record, update the display name if supplied.
            conn.execute("UPDATE interns SET name=? WHERE id=?", (name.strip(), row["id"]))
            conn.commit()
            return conn.execute("SELECT * FROM interns WHERE id=?", (row["id"],)).fetchone()
        conn.execute(
            "INSERT INTO interns(name,email,started_at) VALUES(?,?,?)",
            (name.strip(), email, datetime.now().isoformat(timespec="seconds")),
        )
        conn.commit()
        return conn.execute("SELECT * FROM interns WHERE email=?", (email,)).fetchone()


def list_tasks(intern_id):
    with db() as conn:
        return conn.execute(
            "SELECT * FROM tasks WHERE intern_id=? ORDER BY id DESC", (intern_id,)
        ).fetchall()


def get_task(task_id):
    with db() as conn:
        return conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()


def update_task_status(task_id, status):
    with db() as conn:
        conn.execute("UPDATE tasks SET status=? WHERE id=?", (status, task_id))
        conn.commit()


# -------------------- AI helpers --------------------
def ai_client():
    key = os.getenv("OPENAI_API_KEY", "").strip()
    if not key:
        return None
    return OpenAI(api_key=key)


def ask_ai(instructions, prompt):
    client = ai_client()
    if client is None:
        return None, "OPENAI_API_KEY is not configured. Add it to your .env file and restart the app."
    try:
        response = client.responses.create(
            model=MODEL,
            instructions=instructions,
            input=prompt,
        )
        return response.output_text, None
    except Exception as exc:
        return None, f"AI request failed: {exc}"


def extract_text(uploaded_file):
    name = uploaded_file.name.lower()
    try:
        if name.endswith(".txt"):
            return uploaded_file.getvalue().decode("utf-8", errors="replace")
        if name.endswith(".pdf"):
            reader = PdfReader(uploaded_file)
            pages = []
            for page in reader.pages:
                pages.append(page.extract_text() or "")
            return "\n".join(pages)
        if name.endswith(".docx"):
            doc = Document(uploaded_file)
            return "\n".join(p.text for p in doc.paragraphs)
        return None
    except Exception as exc:
        st.error(f"Could not read the file: {exc}")
        return None


# -------------------- Email --------------------
def send_review_email(intern_name, intern_email, task_title, review_date, review_time, meeting_link):
    host = os.getenv("SMTP_HOST", "").strip()
    port = int(os.getenv("SMTP_PORT", "587"))
    username = os.getenv("SMTP_USERNAME", "").strip()
    password = os.getenv("SMTP_PASSWORD", "").strip()
    sender = os.getenv("EMAIL_FROM", username).strip()

    if not all([host, username, password, sender]):
        return False, "Email settings are missing. Configure SMTP_HOST, SMTP_USERNAME, SMTP_PASSWORD and EMAIL_FROM in .env."

    message = EmailMessage()
    message["Subject"] = f"Internship review schedule: {task_title}"
    message["From"] = sender
    message["To"] = intern_email
    message.set_content(
        f"""Dear {intern_name},

Your next internship review has been scheduled.

Module/task: {task_title}
Review date: {review_date}
Review time: {review_time}
Meeting link: {meeting_link}

Please prepare your work and be ready to explain your implementation and any challenges.

Best regards,
AI Internship Assistant
"""
    )
    try:
        with smtplib.SMTP(host, port, timeout=20) as server:
            server.starttls()
            server.login(username, password)
            server.send_message(message)
        return True, "Review email sent successfully."
    except Exception as exc:
        return False, f"Email could not be sent: {exc}"


# -------------------- UI --------------------
init_db()
st.title("🤖 AI Internship Assistant")
st.caption("Task instructions • Review email • AI report feedback • Repeat until internship completion")

with st.sidebar:
    st.header("Intern profile")
    intern_name = st.text_input("Intern name", placeholder="e.g. Ranjith")
    intern_email = st.text_input("Intern email", placeholder="intern@example.com")
    st.caption("Use a real email only when you are ready to send review notifications.")
    register = st.button("Load / create intern", type="primary", use_container_width=True)

if "intern_id" not in st.session_state:
    st.session_state.intern_id = None

if register:
    if not intern_name.strip() or not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", intern_email.strip()):
        st.sidebar.error("Enter the intern's name and a valid email address.")
    else:
        intern = get_or_create_intern(intern_name, intern_email)
        st.session_state.intern_id = intern["id"]
        st.success(f"Intern profile loaded for {intern['name']}.")

if not st.session_state.intern_id:
    st.info("Start by entering the intern's name and email in the sidebar, then click **Load / create intern**.")
    st.stop()

with db() as conn:
    intern = conn.execute("SELECT * FROM interns WHERE id=?", (st.session_state.intern_id,)).fetchone()

st.markdown(f"**Current intern:** {intern['name']} · `{intern['email']}`")
if intern["internship_complete"]:
    st.success("This internship is marked as completed. An administrator can start a new internship record if needed.")

tabs = st.tabs([
    "1. Task explanation",
    "2. Review email",
    "3. Report feedback",
    "Progress & completion",
])

# Module 1
with tabs[0]:
    st.subheader("Module 1 — Explain the assigned task once")
    with st.form("task_form"):
        title = st.text_input("Task / module title", placeholder="Employee Registration System")
        instructions_text = st.text_area(
            "Assigned task instructions",
            placeholder="Describe what the intern must build or complete...",
            height=140,
        )
        expected_output = st.text_area(
            "Expected output / acceptance criteria",
            placeholder="List the features, report sections, tests, or deliverables expected...",
            height=90,
        )
        due_date = st.text_input("Submission deadline (optional)", placeholder="YYYY-MM-DD")
        create_task_button = st.form_submit_button("Create task")

    if create_task_button:
        if not title.strip() or not instructions_text.strip():
            st.error("Enter a task title and task instructions.")
        else:
            with db() as conn:
                conn.execute(
                    """INSERT INTO tasks
                    (intern_id,title,instructions,expected_output,due_date,status,explained,created_at)
                    VALUES(?,?,?,?,?,'Assigned',0,?)""",
                    (intern["id"], title.strip(), instructions_text.strip(),
                     expected_output.strip(), due_date.strip(),
                     datetime.now().isoformat(timespec="seconds")),
                )
                conn.commit()
            st.success("Task created. Select it below to explain it to the intern.")

    tasks = list_tasks(intern["id"])
    if tasks:
        chosen = st.selectbox(
            "Choose a task",
            tasks,
            format_func=lambda t: f"#{t['id']} — {t['title']} [{t['status']}]",
            key="task_explain_select",
        )
        st.write("**Assigned instructions:**")
        st.write(chosen["instructions"])
        if chosen["expected_output"]:
            st.write("**Expected output:**")
            st.write(chosen["expected_output"])
        if chosen["due_date"]:
            st.write(f"**Deadline:** {chosen['due_date']}")

        if chosen["explained"]:
            st.info("The full task explanation has already been generated for this task. You can still answer specific questions below.")
        else:
            if st.button("Generate task explanation"):
                prompt = f"""Explain this assigned internship task in simple, clear language.
Do not invent company rules or requirements. Organize the answer into:
1. Objective
2. What to do, step by step
3. Tools/technologies (only if supported by the instructions)
4. Expected deliverables
5. Checklist before submission
Mention unknown details as questions for the supervisor.

Task title: {chosen['title']}
Task instructions: {chosen['instructions']}
Expected output: {chosen['expected_output']}
Deadline: {chosen['due_date'] or 'Not specified'}"""
                answer, error = ask_ai(
                    "You are a professional internship task guide. Explain the provided task accurately and do not add unsupported requirements.",
                    prompt,
                )
                if error:
                    st.error(error)
                else:
                    st.session_state[f"task_explanation_{chosen['id']}"] = answer
                    with db() as conn:
                        conn.execute("UPDATE tasks SET explained=1 WHERE id=?", (chosen["id"],))
                        conn.commit()
                    st.rerun()

        explanation = st.session_state.get(f"task_explanation_{chosen['id']}")
        if explanation:
            st.markdown("### Task explanation")
            st.markdown(explanation)

            question = st.text_input("Ask a specific question about this task", key=f"task_question_{chosen['id']}")
            if st.button("Answer my question", key=f"task_answer_btn_{chosen['id']}"):
                if not question.strip():
                    st.warning("Type a question first.")
                else:
                    answer, error = ask_ai(
                        "You clarify an assigned internship task. Use only the task context below. If the answer is not specified, say the intern should confirm with the supervisor.",
                        f"Task: {chosen['title']}\nInstructions: {chosen['instructions']}\nExpected output: {chosen['expected_output']}\nIntern's question: {question}",
                    )
                    if error:
                        st.error(error)
                    else:
                        st.markdown(answer)
    else:
        st.info("No tasks yet. Create the intern's first task above.")

# Module 2
with tabs[1]:
    st.subheader("Module 2 — Schedule a review and email the intern")
    tasks = list_tasks(intern["id"])
    if not tasks:
        st.info("Create a task in Module 1 first.")
    else:
        chosen = st.selectbox(
            "Task for this review",
            tasks,
            format_func=lambda t: f"#{t['id']} — {t['title']}",
            key="review_task_select",
        )
        with st.form("review_form"):
            review_date = st.date_input("Review date")
            review_time = st.time_input("Review time")
            meeting_link = st.text_input("Meeting link", placeholder="https://...")
            send_button = st.form_submit_button("Send review email")
        st.warning("Confirm the date, time, and meeting link with the supervisor before sending.")
        if send_button:
            if not meeting_link.strip().startswith(("https://", "http://")):
                st.error("Enter a valid meeting URL beginning with https:// or http://.")
            else:
                ok, message = send_review_email(
                    intern["name"], intern["email"], chosen["title"],
                    review_date.isoformat(), review_time.strftime("%H:%M"),
                    meeting_link.strip(),
                )
                if ok:
                    with db() as conn:
                        conn.execute(
                            """INSERT INTO review_emails
                            (task_id,review_date,review_time,meeting_link,recipient,sent_at)
                            VALUES(?,?,?,?,?,?)""",
                            (chosen["id"], review_date.isoformat(),
                             review_time.strftime("%H:%M"), meeting_link.strip(),
                             intern["email"], datetime.now().isoformat(timespec="seconds")),
                        )
                        conn.commit()
                    st.success(message)
                else:
                    st.error(message)

# Module 3
with tabs[2]:
    st.subheader("Module 3 — AI report evaluation and corrections")
    tasks = list_tasks(intern["id"])
    if not tasks:
        st.info("Create a task in Module 1 first.")
    else:
        chosen = st.selectbox(
            "Task this submission belongs to",
            tasks,
            format_func=lambda t: f"#{t['id']} — {t['title']}",
            key="submission_task_select",
        )
        upload = st.file_uploader(
            "Upload report (.pdf, .docx, or .txt)",
            type=["pdf", "docx", "txt"],
            key="report_upload",
        )
        if upload:
            if upload.size > 10 * 1024 * 1024:
                st.error("Please upload a file smaller than 10 MB.")
            else:
                if st.button("Evaluate submission with AI", type="primary"):
                    report_text = extract_text(upload)
                    if report_text is None or not report_text.strip():
                        st.error("No readable text was found. Try a text-based PDF, DOCX, or TXT file.")
                    elif len(report_text) > 60000:
                        st.error("This report is too long for this starter version. Please submit a shorter report or evaluate it in sections.")
                    else:
                        with st.spinner("Reviewing the report against the task requirements..."):
                            prompt = f"""Review this intern submission against the actual task instructions.
Do not assume facts not present in the submission. Do not claim to have executed code.
Return:
1. Overall assessment (not an official pass/fail decision)
2. Strengths
3. Issues found, with evidence from the report
4. Required corrections, each with a concrete action
5. Suggested improvements
6. Questions for the intern/supervisor where requirements are unclear
7. Recommendation: 'Corrections required' or 'Ready for supervisor review'
Be fair, constructive, and specific. The supervisor makes the final approval decision.

TASK TITLE:
{chosen['title']}

TASK INSTRUCTIONS:
{chosen['instructions']}

EXPECTED OUTPUT:
{chosen['expected_output'] or 'Not specified'}

SUBMISSION FILE:
{upload.name}

SUBMISSION TEXT:
{report_text}"""
                            feedback, error = ask_ai(
                                "You are a careful technical mentor reviewing internship reports. Give evidence-based feedback, be constructive, and never pretend to execute code or officially approve a submission.",
                                prompt,
                            )
                        if error:
                            st.error(error)
                        else:
                            status = "Corrections Required" if "corrections required" in feedback.lower() else "Ready for supervisor review"
                            with db() as conn:
                                conn.execute(
                                    """INSERT INTO submissions(task_id,filename,feedback,status,submitted_at)
                                    VALUES(?,?,?,?,?)""",
                                    (chosen["id"], upload.name, feedback, status,
                                     datetime.now().isoformat(timespec="seconds")),
                                )
                                conn.execute("UPDATE tasks SET status=? WHERE id=?", (status, chosen["id"]))
                                conn.commit()
                            st.session_state[f"latest_feedback_{chosen['id']}"] = feedback
                            st.markdown("### AI feedback")
                            st.markdown(feedback)
                            st.info("AI feedback is advisory. A supervisor should make the official approval decision.")

        latest = st.session_state.get(f"latest_feedback_{chosen['id']}")
        if latest and not upload:
            st.markdown("### Latest feedback in this session")
            st.markdown(latest)

        with db() as conn:
            submissions = conn.execute(
                "SELECT * FROM submissions WHERE task_id=? ORDER BY id DESC", (chosen["id"],)
            ).fetchall()
        if submissions:
            st.markdown("### Previous submissions")
            for sub in submissions:
                with st.expander(f"{sub['filename']} — {sub['status']} — {sub['submitted_at']}"):
                    st.markdown(sub["feedback"])

# Progress
with tabs[3]:
    st.subheader("Progress, supervisor approval, and internship completion")
    tasks = list_tasks(intern["id"])
    if tasks:
        total = len(tasks)
        approved = sum(1 for t in tasks if t["status"] == "Approved")
        st.metric("Tasks created", total)
        st.metric("Tasks approved", approved)
        st.progress(approved / total if total else 0)
        st.markdown("### Task status")
        for task in tasks:
            col1, col2 = st.columns([3, 2])
            col1.write(f"**#{task['id']} — {task['title']}**")
            col2.write(task["status"])
            if task["status"] in ("Ready for supervisor review", "Corrections Required", "Assigned"):
                if st.button("Supervisor: approve task", key=f"approve_{task['id']}"):
                    update_task_status(task["id"], "Approved")
                    st.rerun()
            st.divider()
    else:
        st.info("Tasks will appear here after you create them.")

    st.markdown("### Internship completion")
    st.caption("Only mark the internship complete after all required tasks and supervisor approvals are finished.")
    if tasks and all(t["status"] == "Approved" for t in tasks):
        if st.button("Mark internship completed", type="primary"):
            with db() as conn:
                conn.execute("UPDATE interns SET internship_complete=1 WHERE id=?", (intern["id"],))
                conn.commit()
            st.success("Internship marked as completed.")
            st.rerun()
    elif tasks:
        st.info("Approve all tasks before marking the internship complete.")
    else:
        st.info("Create at least one task first.")

st.divider()
st.caption("Prototype note: This starter app is intended for demonstration. Add authentication, role permissions, backups, secure deployment, and company-approved data handling before using it with real interns.")
